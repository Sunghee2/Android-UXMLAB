<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require '../vendor/autoload.php';
require_once '../includes/DbOperation.php';

//Creating a new app with the config to show errors
$app = new \Slim\App([
    'settings' => [
        'displayErrorDetails' => true
    ]
]);

//registering a new user
$app->post('/register', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('id', 'password', 'name', 'email'))) {
        $requestData = $request->getParsedBody();
        $id = $requestData['id'];
        $password = $requestData['password'];
        $name = $requestData['name'];
        $email = $requestData['email'];
        $is_student = 1;
        $db = new DbOperation();
        $responseData = array();

        $result = $db->registerUser($id, $password, $name, $email, $is_student);

        if ($result == USER_CREATED) {
            $responseData['error'] = false;
            $responseData['message'] = 'Registered successfully';
            $responseData['user'] = $db->getUserById($id);
        } elseif ($result == USER_CREATION_FAILED) {
            $responseData['error'] = true;
            $responseData['message'] = 'Some error occurred';
        } elseif ($result == USER_EXIST) {
            $responseData['error'] = true;
            $responseData['message'] = 'This email already exist, please login';
        }

        $response->getBody()->write(json_encode($responseData));
    }
});

//user login route
$app->post('/login', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('id', 'password'))) {
        $requestData = $request->getParsedBody();
        $id = $requestData['id'];
        $password = $requestData['password'];

        $db = new DbOperation();

        $responseData = array();

        if ($db->userLogin($id, $password)) {
            $responseData['error'] = false;
            $responseData['user'] = $db->getUserById($id);
        } else {
            $responseData['error'] = true;
            $responseData['message'] = 'Invalid id or password';
        }

        $response->getBody()->write(json_encode($responseData));
    }
});

//course list
$app->post('/course_list', function (Request $request, Response $response){
  if (isTheseParametersAvailable(array('id'))) {
      $requestData = $request->getParsedBody();
      $id = $requestData['id'];

      $db = new DbOperation();

      $responseData = array();
      $courseList = array();

      if ($db->checkMyCourseExist($id)) {
          $responseData['is_my_course'] = true;
          $responseData['my_course'] = $db->getMyCourseList($id);
          $responseData['all_course'] = $db->getAllCourseList($id);
      } else {
          $responseData['is_my_course'] = false;
          $responseData['all_course'] = $db->getAllCourseList($id);
      }

      $response->getBody()->write(json_encode($responseData));
  }
});

// 강의 추가
$app->post('/add_course', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('key', 'no', 'name', 'professor', 'date'))) {
      $requestData = $request->getParsedBody();
      $course_key = $requestData['key'];
      $course_no = $requestData['no'];
      $course_name = $requestData['name'];
      $professor = $requestData['professor'];
      $start_date = $requestData['date'];
      $description = !empty($requestData['description'])? $description : null;
      $db = new DbOperation();
      $responseData = array();

      $result = $db->addCourse($course_key, $course_no, $course_name, $professor, $start_date, $description);

      if ($result == ADD_COURSE) {
          $responseData['error'] = false;
          $responseData['message'] = 'added successfully';
      } elseif ($result == COURSE_ADDITION_FAILED) {
          $responseData['error'] = true;
          $responseData['message'] = 'Some error occurred';
      } elseif ($result == COURSE_EXIST) {
          $responseData['error'] = true;
          $responseData['message'] = 'This course number already exist, please check it';
      }

      $response->getBody()->write(json_encode($responseData));
  }
});

// 강의 삭제
$app->post('/delete_course', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('course_no'))) {
      $requestData = $request->getParsedBody();
      $course_no = $requestData['course_no'];

      $db = new DbOperation();
      $responseData = array();

      $result = $db->deleteCourse($course_no);

      if ($result == DELETE_COURSE) {
          $responseData['error'] = false;
          $responseData['message'] = 'deleted successfully';
      } elseif ($result == COURSE_DELETION_FAILED) {
          $responseData['error'] = true;
          $responseData['message'] = 'Some error occurred';
      } elseif ($result == COURSE_NOT_EXIST) {
          $responseData['error'] = true;
          $responseData['message'] = 'This course does not exist, please check it';
      }

      $response->getBody()->write(json_encode($responseData));
  }
});

// 강의 읽기
$app->post('/read_course', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('course_no'))) {
      $requestData = $request->getParsedBody();
      $course_no = $requestData['course_no'];

      $db = new DbOperation();
      $responseData = array();

      if ($db->isCourseExist($course_no)) {
          $responseData['error'] = false;
          $responseData['course'] = $db->getCourseInfo($course_no);
      } else {
          $responseData['error'] = true;
          $responseData['message'] = 'This course does not exist, please check it';
      }

      $response->getBody()->write(json_encode($responseData));
  }
});


// 강의 수정
$app->post('/edit_course', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('origin_course_no', 'key', 'no', 'name', 'professor', 'date'))) {
      $requestData = $request->getParsedBody();
      $origin_course_no = $requestData['origin_course_no'];
      $course_key = $requestData['key'];
      $course_no = $requestData['no'];
      $course_name = $requestData['name'];
      $professor = $requestData['professor'];
      $start_date = $requestData['date'];
      $description = !empty($requestData['description'])? $description : null;
      $db = new DbOperation();
      $responseData = array();

      $result = $db->editCourse($origin_course_no, $course_key, $course_no, $course_name, $professor, $start_date, $description);

      if ($result == EDIT_COURSE) {
          $responseData['error'] = false;
          $responseData['message'] = 'updated successfully';
      } elseif ($result == COURSE_EDITION_FAILED) {
          $responseData['error'] = true;
          $responseData['message'] = 'Some error occurred';
      } elseif ($result == COURSE_NOT_EXIST) {
          $responseData['error'] = true;
          $responseData['message'] = 'This course does not exist, please check it';
      }

      $response->getBody()->write(json_encode($responseData));
  }
});

// 강의 등록
$app->post('/register_course', function (Request $request, Response $response) {
    if (isTheseParametersAvailable(array('course_key', 'course_no', 'id'))) {
      $requestData = $request->getParsedBody();
      $course_key = $requestData['course_key'];
      $course_no = $requestData['course_no'];
      $id = $requestData['id'];

      $db = new DbOperation();
      $responseData = array();

      $result = $db->registerCourse($course_key, $course_no, $id);

      if ($result == REGISTER_COURSE) {
          $responseData['error'] = false;
          $responseData['message'] = 'registered successfully';
      } elseif ($result == COURSE_REGISTRATION_FAILED) {
          $responseData['error'] = true;
          $responseData['message'] = 'Some error occurred';
      } elseif ($result == COURSE_KEY_ERROR) {
          $responseData['error'] = true;
          $responseData['message'] = 'The Key you entered is not valid';
      } elseif ($result == COURSE_NOT_EXIST) {
          $responseData['error'] = true;
          $responseData['message'] = 'This course does not exist, please check it';
      }

      $response->getBody()->write(json_encode($responseData));
  }
});
// //getting all users
// $app->get('/users', function (Request $request, Response $response) {
//     $db = new DbOperation();
//     $users = $db->getAllUsers();
//     $response->getBody()->write(json_encode(array("users" => $users)));
// });

// //updating a user
// $app->post('/update/{id}', function (Request $request, Response $response) {
//     if (isTheseParametersAvailable(array('name', 'email', 'password', 'gender'))) {
//         $id = $request->getAttribute('id');

//         $requestData = $request->getParsedBody();

//         $name = $requestData['name'];
//         $email = $requestData['email'];
//         $password = $requestData['password'];
//         $gender = $requestData['gender'];


//         $db = new DbOperation();

//         $responseData = array();

//         if ($db->updateProfile($id, $name, $email, $password, $gender)) {
//             $responseData['error'] = false;
//             $responseData['message'] = 'Updated successfully';
//             $responseData['user'] = $db->getUserByEmail($email);
//         } else {
//             $responseData['error'] = true;
//             $responseData['message'] = 'Not updated';
//         }

//         $response->getBody()->write(json_encode($responseData));
//     }
// });

//function to check parameters
function isTheseParametersAvailable($required_fields)
{
    $error = false;
    $error_fields = "";
    $request_params = $_REQUEST;

    foreach ($required_fields as $field) {
        if (!isset($request_params[$field]) || strlen(trim($request_params[$field])) <= 0) {
            $error = true;
            $error_fields .= $field . ', ';
        }
    }

    if ($error) {
        $response = array();
        $response["error"] = true;
        $response["message"] = 'Required field(s) ' . substr($error_fields, 0, -2) . ' is missing or empty';
        echo json_encode($response);
        return false;
    }
    return true;
}


$app->run();
