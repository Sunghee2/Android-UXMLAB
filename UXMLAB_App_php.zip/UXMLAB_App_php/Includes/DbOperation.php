<?php

class DbOperation {
  private $con;

  function __construct() {
    require_once dirname(__FILE__) . '/DbConnect.php';
    $db = new DbConnect();
    $this->con = $db->connect();
  }

  //Method to create a new user
  function registerUser($id, $pass, $name, $email, $is_student)
  {
      if (!$this->isUserExist($email)) {
          //$password = md5($pass);
          $password = $pass; // 추후 암호화 방식 추가 필요
          $stmt = $this->con->prepare("INSERT INTO users (id, password, name, email, is_student) VALUES (?, ?, ?, ?, ?)");
          $stmt->bind_param("isssi", $id, $pass, $name, $email, $is_student);
          if ($stmt->execute())
              return USER_CREATED;
          return USER_CREATION_FAILED;
      }
      return USER_EXIST;
  }

  //Method for user login
  function userLogin($id, $pass)
  {
      //$password = md5($pass); // 추후 다른 암호화 방식으로 교체 필요
      $password = $pass;
      $stmt = $this->con->prepare("SELECT id FROM users WHERE id = ? AND password = ?");
      $stmt->bind_param("is", $id, $password);
      $stmt->execute();
      $stmt->store_result();
      return $stmt->num_rows > 0;
  }

  // //Method to update profile of user
  // function updateProfile($id, $name, $email, $pass, $gender)
  // {
  //     $password = md5($pass);
  //     $stmt = $this->con->prepare("UPDATE users SET name = ?, email = ?, password = ?, gender = ? WHERE id = ?");
  //     $stmt->bind_param("ssssi", $name, $email, $password, $gender, $id);
  //     if ($stmt->execute())
  //         return true;
  //     return false;
  // }

  //Method to get user by email
  function getUserById($id)
  {
      $stmt = $this->con->prepare("SELECT id, name, email, is_student FROM users WHERE id = ?");
      $stmt->bind_param("i", $id);
      $stmt->execute();
      $stmt->bind_result($id, $name, $email, $is_student);
      $stmt->fetch();
      $user = array();
      $user['id'] = $id;
      $user['name'] = $name;
      $user['email'] = $email;
      $user['is_student'] = $is_student;
      return $user;
  }

  //Method to get my course by id
  function getMyCourseList($id)
  {
    $stmt = $this->con->prepare("SELECT course_no, course_name, professor from Course where course_no in (select e.course_no from enroll e where id = ?)");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($course_no, $course_name, $professor);

    $course = array();

    $result = $stmt->get_result();
    while($row = $result->fetch_array(MYSQLI_ASSOC)){
      $course[] = $row;
    }

    return $course;
  }

  function getAllCourseList($id)
  {
    $stmt = $this->con->prepare("SELECT course_no, course_name, professor from Course where course_no not in (select e.course_no from enroll e where id = ?)");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($course_no, $course_name, $professor);

    $course = array();

    $result = $stmt->get_result();
    while($row = $result->fetch_array(MYSQLI_ASSOC)){
      $course[] = $row;
    }

    return $course;
  }


  // 강의 등록
  function addCourse($course_key, $course_no, $course_name, $professor, $start_date, $description)
  {
      if (!$this->isCourseExist($course_no)) {
          $stmt = $this->con->prepare("INSERT INTO Course (course_key, course_no, course_name, professor, start_date, description) VALUES (?, ?, ?, ?, ?, ?)");
          $stmt->bind_param("ssssss", $course_key, $course_no, $course_name, $professor, $start_date, $description);
          if ($stmt->execute())
              return ADD_COURSE;
          return COURSE_ADDITION_FAILED;
      }
      return COURSE_EXIST;
  }

  // 강의 삭제
  function deleteCourse($course_no)
  {
    if ($this->isCourseExist($course_no)) {
        $stmt = $this->con->prepare("DELETE FROM Course where course_no=?");
        $stmt->bind_param("s", $course_no);
        if ($stmt->execute())
            return DELETE_COURSE;
        return COURSE_DELETION_FAILED;
    }
    return COURSE_NOT_EXIST;
  }

//강의 정보
  function getCourseInfo($course_no)
  {
    $stmt = $this->con->prepare("SELECT * from Course where course_no = ?");
    $stmt->bind_param("s", $course_no);
    $stmt->execute();
    $stmt->bind_result($course_key, $course_no, $course_name, $professor, $start_date, $description);
    $stmt->fetch();


    $course = array();
    $course['course_key'] = $course_key;
    $course['course_no'] = $course_no;
    $course['course_name'] = $course_name;
    $course['professor'] = $professor;
    $course['start_date'] = $start_date;
    $course['description'] = $description;
    return $course;
  }

  // 강의 수정
  function editCourse($origin_course_no, $course_key, $course_no, $course_name, $professor, $start_date, $description)
  {
      if ($this->isCourseExist($origin_course_no)) {
          $stmt = $this->con->prepare("UPDATE Course set course_key= ?, course_no= ?, course_name= ?, professor= ?, start_date= ?, description= ? where course_no=");
          $stmt->bind_param("sssssss", $course_key, $course_no, $course_name, $professor, $start_date, $description, $origin_course_no);
          if ($stmt->execute())
              return EDIT_COURSE;
          return COURSE_EDITION_FAILED;
      }
      return COURSE_NOT_EXIST;
  }

  // 강의 등록
  function registerCourse($course_key, $course_no, $id)
  {
      if ($this->isCourseExist($course_no)) {
        if($this->checkKey($course_no, $course_key)) {
          $stmt = $this->con->prepare("INSERT into enroll (id, course_no) values (?, ?)");
          $stmt->bind_param("is", $id, $course_no);
          if ($stmt->execute()) {
            return REGISTER_COURSE;
          }
          return COURSE_REGISTRATION_FAILED;
        }
        return COURSE_KEY_ERROR;
      }
      return COURSE_NOT_EXIST;
  }
  // //Method to get all users
  // function getAllUsers(){
  //     $stmt = $this->con->prepare("SELECT id, name, email, gender FROM users");
  //     $stmt->execute();
  //     $stmt->bind_result($id, $name, $email, $gender);
  //     $users = array();
  //     while($stmt->fetch()){
  //         $temp = array();
  //         $temp['id'] = $id;
  //         $temp['name'] = $name;
  //         $temp['email'] = $email;
  //         $temp['gender'] = $gender;
  //         array_push($users, $temp);
  //     }
  //     return $users;
  // }

  //Method to check if email already exist
    function isUserExist($email)
    {
        $stmt = $this->con->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        return $stmt->num_rows > 0;
    }


    // 내 강의가 있는지 확인
    function checkMyCourseExist($id)
    {
      $stmt = $this->con->prepare("SELECT course_no FROM Course WHERE course_no IN (SELECT e.course_no FROM enroll e WHERE id = ?)");
      $stmt->bind_param("s", $id);
      $stmt->execute();
      $stmt->store_result();
      return $stmt->num_rows > 0;
    }

    // 강의 등록할 때 이미 존재하는지 확인
    function isCourseExist($course_no)
    {
      $stmt = $this->con->prepare("SELECT course_name from Course where course_no= ?");
      $stmt->bind_param("s", $course_no);
      $stmt->execute();
      $stmt->store_result();
      return $stmt->num_rows > 0;
    }

    function checkKey($course_no, $course_key)
    {
      $stmt = $this->con->prepare("SELECT course_name from Course where course_no= ? and course_key= ?");
      $stmt->bind_param("ss", $course_no, $course_key);
      $stmt->execute();
      $stmt->store_result();
      return $stmt->num_rows > 0;
    }

}

// /* userLogin Test */
// $db = new DbOperation();
// $result = $db->userLogin($id, $password);
// echo $result;


?>
