<?php

 define('DB_USERNAME', 'root');
 define('DB_PASSWORD', '');
 define('DB_HOST', 'localhost');
 define('DB_NAME', 'UXMLAB');

 define('USER_CREATED', 101);
 define('USER_EXIST', 102);
 define('USER_CREATION_FAILED', 103);

 ?>
